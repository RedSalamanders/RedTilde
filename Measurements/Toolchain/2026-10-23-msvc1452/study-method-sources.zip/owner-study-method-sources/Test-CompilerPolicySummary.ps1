$ErrorActionPreference='Stop'
$root='E:\DxUi.Perf\compiler-policy\summary-controls'
[void][IO.Directory]::CreateDirectory($root)
$plan=@{repository='SyntheticSummaryControl';blocks=12;diagnosticSharedHost=$false}
$complete=@{passed=$true;sampleCount=48}
$samples=foreach($block in 0..11){foreach($position in 'A1','A2','B1','B2'){@{scenario='Synthetic';block=$block;position=$position;exitCode=0;preBuildActivity=@();metrics=@{durationUs=$(if($position.StartsWith('A')){100.0}else{50.0})}}}}
function Run-Control([string]$Name,[object[]]$Samples,[string]$Expected){
 $directory=Join-Path $root $Name
 [void][IO.Directory]::CreateDirectory($directory)
 $plan|ConvertTo-Json|Set-Content (Join-Path $directory 'plan.json')
 $complete|ConvertTo-Json|Set-Content (Join-Path $directory 'complete.json')
 $Samples|ConvertTo-Json -Depth 5|Set-Content (Join-Path $directory 'samples.json')
 & pwsh -NoProfile -File E:\DxUi.Perf\Summarize-CompilerPolicy.ps1 -Study $directory *> (Join-Path $directory 'output.log')
 if($LASTEXITCODE){throw "Unexpected summary failure: $Name"}
 $result=Get-Content (Join-Path $directory 'comparison.json') -Raw|ConvertFrom-Json
 if($result.rows[0].finding-cne $Expected){throw "Wrong finding for $Name"}
 Write-Output "$Name passed: $Expected"
}
Run-Control 'stable-known-improvement' $samples 'measured fixture improvement'
$samples[0].preBuildActivity=@(@{Id=123;ProcessName='synthetic-compiler-control'})
Run-Control 'contaminated-improvement' $samples 'inconclusive - concurrent activity observed'
$samples[0].preBuildActivity=@()
$samples[0].duringBuildActivity=@(@{Id=124;ProcessName='synthetic-during-compiler-control'})
Run-Control 'during-contaminated-improvement' $samples 'inconclusive - concurrent activity observed'
$samples[0].duringBuildActivity=@()
$samples[0].postBuildActivity=@(@{Id=125;ProcessName='synthetic-post-compiler-control'})
Run-Control 'post-contaminated-improvement' $samples 'inconclusive - concurrent activity observed'
$samples[0].postBuildActivity=@()
$samples[1].metrics.durationUs=150.0
Run-Control 'unstable-known-improvement' $samples 'inconclusive - unstable controls'