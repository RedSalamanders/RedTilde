[CmdletBinding()]
param([Parameter(Mandatory)][string]$Study)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
function Median([double[]]$Values){$s=@($Values|Sort-Object);$m=[int][math]::Floor($s.Count/2);if($s.Count%2){return $s[$m]};return ($s[$m-1]+$s[$m])/2}
function SignFlip([double[]]$Values){$observed=[math]::Abs(($Values|Measure-Object -Sum).Sum);$extreme=0;$count=1-shl $Values.Count;for($mask=0;$mask-lt $count;$mask++){$sum=0.0;for($i=0;$i-lt $Values.Count;$i++){$sum+=$(if($mask-band (1-shl $i)){-$Values[$i]}else{$Values[$i]})};if([math]::Abs($sum)-ge $observed-1e-12){$extreme++}};return $extreme/[double]$count}
# Arithmetic controls independent of the measurement source.
if([math]::Abs((SignFlip @(1.0,1.0,1.0,1.0))-0.125)-gt 1e-12){throw 'Sign-flip positive control failed.'}
if((SignFlip @(1.0,-1.0,1.0,-1.0))-ne 1.0){throw 'Sign-flip null control failed.'}
if((Median @(4,1,2,3))-ne 2.5){throw 'Median control failed.'}
$plan=Get-Content (Join-Path $Study 'plan.json') -Raw|ConvertFrom-Json -AsHashtable
$complete=Get-Content (Join-Path $Study 'complete.json') -Raw|ConvertFrom-Json -AsHashtable
if(-not $complete.passed){throw 'Incomplete study.'}
$samples=@(Get-Content (Join-Path $Study 'samples.json') -Raw|ConvertFrom-Json -AsHashtable)
if($samples.Count-ne $complete.sampleCount){throw 'Sample inventory mismatch.'}
$rows=[Collections.Generic.List[object]]::new()
$scenarios=@($samples.scenario|Sort-Object -Unique)
foreach($scenario in $scenarios){
    $selected=@($samples|Where-Object {$_.scenario-ceq $scenario-and $_.block-ge 0})
    $keys=@($selected[0].metrics.Keys|Sort-Object)
    foreach($sample in $selected){if($sample.exitCode-ne 0-or ($sample.metrics.Keys|Sort-Object)-join ';' -cne ($keys-join ';')){throw 'Failed sample or inconsistent metric inventory.'}}
    foreach($key in $keys){
        $baseline=[Collections.Generic.List[double]]::new();$candidate=[Collections.Generic.List[double]]::new();$logs=[Collections.Generic.List[double]]::new();$controls=[Collections.Generic.List[double]]::new()
        for($block=0;$block-lt $plan.blocks;$block++){
            $v=@{};foreach($position in 'A1','A2','B1','B2'){$s=@($selected|Where-Object {$_.block-eq $block-and $_.position-ceq $position});if($s.Count-ne 1){throw 'Missing/duplicate block member.'};$number=[double]$s[0].metrics[$key];if(-not [double]::IsFinite($number)-or $number-le 0){throw 'Nonpositive/nonfinite primary metric.'};$v[$position]=$number}
            $baseline.Add($v.A1);$baseline.Add($v.A2);$candidate.Add($v.B1);$candidate.Add($v.B2)
            $logs.Add(([math]::Log($v.B1)+[math]::Log($v.B2)-[math]::Log($v.A1)-[math]::Log($v.A2))/2)
            $controls.Add([math]::Abs($v.A2/$v.A1-1));$controls.Add([math]::Abs($v.B2/$v.B1-1))
        }
        $band=if($key-match 'Bytes$'){0.02}else{0.05}
        $rows.Add([ordered]@{repository=$plan.repository;scenario=$scenario;metric=$key;blocks=$plan.blocks;baselineMedian=(Median $baseline.ToArray());candidateMedian=(Median $candidate.ToArray());pairedChangePercent=100*([math]::Exp(($logs|Measure-Object -Average).Average)-1);p=(SignFlip $logs.ToArray());controlBandPercent=100*$band;unstableControls=@($controls|Where-Object {$_-gt $band}).Count;controls=$controls.ToArray();blockLogRatios=$logs.ToArray()})
    }
}
$buildObserved=@($samples|Where-Object {$sample=$_;@('preBuildActivity','duringBuildActivity','postBuildActivity'|Where-Object {$sample.ContainsKey($_)-and @($sample[$_]).Count-gt 0}).Count-gt 0}).Count
$sorted=@($rows|Sort-Object {$_['p']});$previous=0.0
for($i=0;$i-lt $sorted.Count;$i++){$row=$sorted[$i];$adjusted=[math]::Min(1,[math]::Max($previous,$row.p*($sorted.Count-$i)));$previous=$adjusted;$row.adjustedP=$adjusted;$row.finding=if($plan.diagnosticSharedHost){'diagnostic shared-host pilot'}elseif($buildObserved){'inconclusive - concurrent activity observed'}elseif($row.unstableControls){'inconclusive - unstable controls'}elseif($adjusted-le 0.05-and $row.pairedChangePercent-gt $row.controlBandPercent){'measured fixture regression'}elseif($adjusted-le 0.05-and $row.pairedChangePercent-lt -$row.controlBandPercent){'measured fixture improvement'}else{'no significant fixture change detected; not non-regression proof'}}
$buildObserved=@($samples|Where-Object {$sample=$_;@('preBuildActivity','duringBuildActivity','postBuildActivity'|Where-Object {$sample.ContainsKey($_)-and @($sample[$_]).Count-gt 0}).Count-gt 0}).Count
$report=[ordered]@{repository=$plan.repository;study=$Study;blocks=$plan.blocks;primaryFamilySize=$rows.Count;diagnosticSharedHost=$plan.diagnosticSharedHost;samplesWithCompilationObserved=$buildObserved;samplesWithConcurrentActivityObserved=$buildObserved;method='Median of native process summaries; geometric paired ABBA/BAAB block ratio; exact two-sided sign-flip p; Holm correction within repository family. Same-side controls use 5 percent timing/2 percent memory bands. No production/performance-policy qualification is implied.';rows=$rows.ToArray()}
$report|ConvertTo-Json -Depth 8|Set-Content (Join-Path $Study 'comparison.json')
$rows|ForEach-Object {[pscustomobject]$_}|Select-Object repository,scenario,metric,baselineMedian,candidateMedian,pairedChangePercent,adjustedP,unstableControls,finding|Format-Table -Wrap
# Publish only real completed owner studies; synthetic controls remain isolated.
$owner=$plan.repository
$realParent=if($owner-in @('DxUi','RedXe','RedSalamander','RedPrism','RedTilde')){[IO.Path]::GetFullPath("E:\$owner.Perf\compiler-policy-study").TrimEnd('\')}else{''}
if($plan.blocks-eq 12-and $realParent-and [IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Study).TrimEnd('\'))-ceq $realParent){
 & 'E:\DxUi.Perf\Publish-CompilerPolicyEvidence.ps1' -Study $Study
}